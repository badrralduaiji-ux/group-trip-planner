
import os
from datetime import datetime
from decimal import Decimal, InvalidOperation
from typing import Optional

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import (
    Boolean, Date, DateTime, ForeignKey, Integer, Numeric, String, Text,
    UniqueConstraint, create_engine, func, select
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from starlette.middleware.sessions import SessionMiddleware

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'trip_planner.db')}")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, future=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

CONSENSUS_REQUIRED = 7
ADMIN_CODE = os.getenv("ADMIN_CODE", "badr-trip")


class Base(DeclarativeBase):
    pass


class Participant(Base):
    __tablename__ = "participant"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    email: Mapped[str] = mapped_column(String(160), default="")
    is_organizer: Mapped[bool] = mapped_column(Boolean, default=False)
    preference: Mapped[Optional["Preference"]] = relationship(back_populates="participant", uselist=False)


class Destination(Base):
    __tablename__ = "destination"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(60), unique=True)
    title: Mapped[str] = mapped_column(String(120))
    subtitle: Mapped[str] = mapped_column(String(180))
    emoji: Mapped[str] = mapped_column(String(10))
    summary: Mapped[str] = mapped_column(Text)
    flight_note: Mapped[str] = mapped_column(String(220))
    budget_note: Mapped[str] = mapped_column(String(160))
    pace: Mapped[str] = mapped_column(String(120))
    why_it_fits: Mapped[str] = mapped_column(Text)
    source_note: Mapped[str] = mapped_column(Text, default="")
    activities: Mapped[list["Activity"]] = relationship(back_populates="destination", order_by="Activity.day_no")


class Activity(Base):
    __tablename__ = "activity"
    id: Mapped[int] = mapped_column(primary_key=True)
    destination_id: Mapped[int] = mapped_column(ForeignKey("destination.id"))
    day_no: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(150))
    category: Mapped[str] = mapped_column(String(60))
    description: Mapped[str] = mapped_column(Text)
    destination: Mapped[Destination] = relationship(back_populates="activities")


class Preference(Base):
    __tablename__ = "preference"
    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participant.id"), unique=True)
    budget_min: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    budget_max: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    preferred_month: Mapped[str] = mapped_column(String(80), default="")
    pace: Mapped[str] = mapped_column(String(30), default="balanced")
    room_preference: Mapped[str] = mapped_column(String(80), default="")
    must_have: Mapped[str] = mapped_column(String(180), default="")
    deal_breaker: Mapped[str] = mapped_column(String(180), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    participant: Mapped[Participant] = relationship(back_populates="preference")


class DestinationVote(Base):
    __tablename__ = "destination_vote"
    __table_args__ = (UniqueConstraint("participant_id", "destination_id", name="uq_destination_vote"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participant.id"))
    destination_id: Mapped[int] = mapped_column(ForeignKey("destination.id"))
    score: Mapped[int] = mapped_column(Integer, default=3)
    rank: Mapped[int] = mapped_column(Integer, default=2)
    support: Mapped[str] = mapped_column(String(12), default="maybe")
    comment: Mapped[str] = mapped_column(String(260), default="")


class ActivityVote(Base):
    __tablename__ = "activity_vote"
    __table_args__ = (UniqueConstraint("participant_id", "activity_id", name="uq_activity_vote"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participant.id"))
    activity_id: Mapped[int] = mapped_column(ForeignKey("activity.id"))
    vote: Mapped[str] = mapped_column(String(12), default="maybe")


class DateOption(Base):
    __tablename__ = "date_option"
    id: Mapped[int] = mapped_column(primary_key=True)
    label: Mapped[str] = mapped_column(String(120))
    start_date: Mapped[datetime.date] = mapped_column(Date)
    end_date: Mapped[datetime.date] = mapped_column(Date)
    created_by: Mapped[int] = mapped_column(ForeignKey("participant.id"))


class DateVote(Base):
    __tablename__ = "date_vote"
    __table_args__ = (UniqueConstraint("participant_id", "date_option_id", name="uq_date_vote"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participant.id"))
    date_option_id: Mapped[int] = mapped_column(ForeignKey("date_option.id"))
    vote: Mapped[str] = mapped_column(String(12), default="maybe")


class Comment(Base):
    __tablename__ = "comment"
    id: Mapped[int] = mapped_column(primary_key=True)
    participant_id: Mapped[int] = mapped_column(ForeignKey("participant.id"))
    destination_id: Mapped[Optional[int]] = mapped_column(ForeignKey("destination.id"), nullable=True)
    body: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    participant: Mapped[Participant] = relationship()
    destination: Mapped[Optional[Destination]] = relationship()


class Setting(Base):
    __tablename__ = "setting"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[str] = mapped_column(String(255), default="")


class Reservation(Base):
    __tablename__ = "reservation"
    id: Mapped[int] = mapped_column(primary_key=True)
    category: Mapped[str] = mapped_column(String(50))
    item: Mapped[str] = mapped_column(String(180))
    provider: Mapped[str] = mapped_column(String(150), default="")
    status: Mapped[str] = mapped_column(String(30), default="researching")
    due_date: Mapped[Optional[datetime.date]] = mapped_column(Date, nullable=True)
    amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True)
    currency: Mapped[str] = mapped_column(String(10), default="SAR")
    confirmation: Mapped[str] = mapped_column(String(120), default="")
    owner: Mapped[str] = mapped_column(String(100), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


app = FastAPI(title="Nine Away")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY", "dev-secret-change-me"))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


def seed_data():
    with SessionLocal() as db:
        if db.scalar(select(func.count()).select_from(Participant)) == 0:
            names = ["Badr", "Wife", "Friend 1", "Friend 2", "Friend 3", "Friend 4", "Friend 5", "Friend 6", "Friend 7"]
            db.add_all([Participant(name=name, is_organizer=(idx == 0)) for idx, name in enumerate(names)])
            db.commit()

        if db.scalar(select(func.count()).select_from(Destination)) == 0:
            destinations = [
                Destination(
                    slug="cyprus", title="Limassol + Paphos", subtitle="The Mediterranean resort reset", emoji="🌊",
                    summary="A polished, low-friction week built around a beachfront base, excellent hotels, boat time, old towns, spa afternoons and relaxed dinners. It is the easiest option for a mixed group that wants quality without a packed schedule.",
                    flight_note="Plan around Larnaca or Paphos access; verify the exact nonstop schedule for the chosen week before locking.",
                    budget_note="Planning range: SAR 8,000–13,000 per person, excluding shopping.",
                    pace="Relaxed to balanced",
                    why_it_fits="Premium hotels, sea views and enough structure to keep nine people together—without turning every day into a tour.",
                    source_note="Cyprus tourism authority highlights sea, gastronomy, nature, wellness and romance as core experiences."
                ),
                Destination(
                    slug="georgia", title="Tbilisi + Kazbegi", subtitle="The scenic, social and best-value week", emoji="⛰️",
                    summary="Three nights in Tbilisi, a private-group road trip through the mountains, two nights near Kazbegi and a final relaxed city night. Strong food, private vans, scenery and flexible group activities make this the easiest value winner.",
                    flight_note="Riyadh–Tbilisi nonstop service is commonly scheduled at roughly 3h 45m; confirm dates and cabin before purchase.",
                    budget_note="Planning range: SAR 5,500–9,000 per person, excluding shopping.",
                    pace="Balanced",
                    why_it_fits="Short flight, meat-friendly dining, strong hotel value and enough scenery and activities to give the group something to vote on.",
                    source_note="Current route listings show nonstop Riyadh–Tbilisi service; schedules can change."
                ),
                Destination(
                    slug="hong-kong-macau", title="Hong Kong + Macau", subtitle="The premium city, food and casino week", emoji="🌃",
                    summary="Four nights in Hong Kong and three in Macau: skyline hotels, harbour dining, shopping, a private food day and one adults-only casino evening. This is the most premium, energetic and distinctive option.",
                    flight_note="Direct Riyadh–Hong Kong service is listed from late October 2026; earlier dates may require a connection.",
                    budget_note="Planning range: SAR 12,000–20,000 per person, excluding gaming and shopping.",
                    pace="Balanced to active",
                    why_it_fits="High-end hotels, excellent dining, polished transport and a casino component—while still offering plenty for non-gamblers.",
                    source_note="Route listings show Cathay Pacific nonstop Riyadh–Hong Kong service beginning 25 Oct 2026; re-check before booking."
                )
            ]
            db.add_all(destinations)
            db.commit()

            itinerary_map = {
                "cyprus": [
                    (1, "Arrival and beachfront check-in", "Hotel", "Private transfers, easy lunch, pool time and a welcome dinner."),
                    (2, "Limassol old town and marina", "Culture", "Late start, old town walk, marina lunch and free afternoon."),
                    (3, "Private catamaran day", "Sea", "Half-day charter with swimming stops and lunch for the group."),
                    (4, "Choose-your-own day", "Flexible", "Spa, beach, golf or shopping; regroup for dinner."),
                    (5, "Paphos and archaeological coast", "Day trip", "Private van, coastal viewpoints and sunset dinner."),
                    (6, "Troodos villages and tasting", "Nature", "Mountain villages, local food and a relaxed drive."),
                    (7, "Slow morning and departure", "Travel", "Breakfast, final swim and private airport transfer.")
                ],
                "georgia": [
                    (1, "Arrival and Tbilisi dinner", "City", "Central hotel, old-town orientation and a Georgian feast."),
                    (2, "Old Tbilisi and sulphur-bath slots", "Culture", "Guided walk, cable car and optional private bath bookings."),
                    (3, "Kakheti food and countryside day", "Food", "Private van, countryside lunch and non-alcoholic tasting options."),
                    (4, "Military Highway to Kazbegi", "Road trip", "Viewpoints, fortress stop and mountain-hotel check-in."),
                    (5, "Kazbegi your-way day", "Nature", "4x4 church visit, easy hike, spa or hotel downtime."),
                    (6, "Return to Tbilisi", "Flexible", "Leisurely drive back, shopping and a final group dinner."),
                    (7, "Brunch and departure", "Travel", "Late breakfast and airport transfer.")
                ],
                "hong-kong-macau": [
                    (1, "Hong Kong skyline arrival", "City", "Harbour hotel, easy walk and rooftop welcome dinner."),
                    (2, "Private food and neighbourhood day", "Food", "Dim sum, markets, local guide and free evening."),
                    (3, "Victoria Peak and harbour cruise", "Views", "Late start, Peak experience and evening cruise."),
                    (4, "Choose-your-own Hong Kong", "Flexible", "Shopping, spa, Disneyland or a quiet hotel day."),
                    (5, "Ferry to Macau", "Transfer", "Premium ferry, resort check-in and old-town dinner."),
                    (6, "Macau split day", "Flexible", "Heritage route for some; spa, shopping or casino for others."),
                    (7, "Slow morning and departure", "Travel", "Brunch, final resort time and airport transfer.")
                ]
            }
            for destination in db.scalars(select(Destination)).all():
                for day_no, title, category, description in itinerary_map[destination.slug]:
                    db.add(Activity(
                        destination_id=destination.id, day_no=day_no, title=title,
                        category=category, description=description
                    ))
            db.commit()


Base.metadata.create_all(engine)
seed_data()


def add_flash(request: Request, message: str, category: str = "success"):
    flashes = request.session.get("_flashes", [])
    flashes.append((category, message))
    request.session["_flashes"] = flashes


def pop_flashes(request: Request):
    return request.session.pop("_flashes", [])


def route_url(request: Request):
    def helper(name: str, **params):
        if name == "static" and "filename" in params:
            params["path"] = params.pop("filename")
        return request.url_for(name, **params)
    return helper


def render(request: Request, template_name: str, context: dict):
    context = {
        **context,
        "request": request,
        "url_for": route_url(request),
        "get_flashed_messages": lambda with_categories=False: pop_flashes(request),
    }
    return templates.TemplateResponse(request=request, name=template_name, context=context)


def redirect(request: Request, route_name: str, anchor: str = ""):
    return RedirectResponse(str(request.url_for(route_name)) + anchor, status_code=303)


def current_participant(request: Request, db):
    participant_id = request.session.get("participant_id")
    return db.get(Participant, participant_id) if participant_id else None


def get_setting(db, key: str, default: str = ""):
    setting = db.get(Setting, key)
    return setting.value if setting else default


def set_setting(db, key: str, value):
    setting = db.get(Setting, key)
    if setting:
        setting.value = str(value)
    else:
        db.add(Setting(key=key, value=str(value)))
    db.commit()


def to_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def dashboard_data(db):
    participants = db.scalars(select(Participant).order_by(Participant.id)).all()
    destinations = db.scalars(select(Destination).order_by(Destination.id)).all()
    destination_stats = []
    for destination in destinations:
        votes = db.scalars(select(DestinationVote).where(DestinationVote.destination_id == destination.id)).all()
        yes_count = sum(v.support == "yes" for v in votes)
        maybe_count = sum(v.support == "maybe" for v in votes)
        no_count = sum(v.support == "no" for v in votes)
        avg_score = round(sum(v.score for v in votes) / len(votes), 1) if votes else 0
        rank_one = sum(v.rank == 1 for v in votes)
        destination_stats.append({
            "destination": destination, "yes": yes_count, "maybe": maybe_count, "no": no_count,
            "avg_score": avg_score, "rank_one": rank_one, "responses": len(votes),
            "consensus": yes_count >= CONSENSUS_REQUIRED,
            "progress": min(100, round((yes_count / CONSENSUS_REQUIRED) * 100))
        })
    locked_id = get_setting(db, "locked_destination_id")
    locked_destination = db.get(Destination, int(locked_id)) if locked_id.isdigit() else None
    return {
        "participants": participants, "destinations": destinations,
        "destination_stats": destination_stats, "locked_destination": locked_destination,
        "consensus_required": CONSENSUS_REQUIRED, "total_people": len(participants)
    }


@app.get("/", response_class=HTMLResponse, name="index")
async def index(request: Request):
    with SessionLocal() as db:
        participant = current_participant(request, db)
        data = dashboard_data(db)
        date_options = db.scalars(select(DateOption).order_by(DateOption.start_date)).all()
        comments = db.scalars(select(Comment).order_by(Comment.created_at.desc()).limit(30)).all()

        my_dest_votes = {}
        my_activity_votes = {}
        my_date_votes = {}
        if participant:
            my_dest_votes = {v.destination_id: v for v in db.scalars(select(DestinationVote).where(DestinationVote.participant_id == participant.id)).all()}
            my_activity_votes = {v.activity_id: v.vote for v in db.scalars(select(ActivityVote).where(ActivityVote.participant_id == participant.id)).all()}
            my_date_votes = {v.date_option_id: v.vote for v in db.scalars(select(DateVote).where(DateVote.participant_id == participant.id)).all()}

        date_stats = []
        for option in date_options:
            votes = db.scalars(select(DateVote).where(DateVote.date_option_id == option.id)).all()
            date_stats.append({
                "option": option,
                "yes": sum(v.vote == "yes" for v in votes),
                "maybe": sum(v.vote == "maybe" for v in votes),
                "no": sum(v.vote == "no" for v in votes),
            })

        activity_stats = {}
        for destination in data["destinations"]:
            activity_stats[destination.id] = []
            for activity in destination.activities:
                votes = db.scalars(select(ActivityVote).where(ActivityVote.activity_id == activity.id)).all()
                activity_stats[destination.id].append({
                    "activity": activity,
                    "yes": sum(v.vote == "yes" for v in votes),
                    "maybe": sum(v.vote == "maybe" for v in votes),
                    "no": sum(v.vote == "no" for v in votes),
                })

        return render(request, "index.html", {
            **data, "participant": participant, "date_stats": date_stats, "comments": comments,
            "my_dest_votes": my_dest_votes, "my_activity_votes": my_activity_votes,
            "my_date_votes": my_date_votes, "activity_stats": activity_stats
        })


@app.post("/select-participant", name="select_participant")
async def select_participant(request: Request):
    form = await request.form()
    with SessionLocal() as db:
        participant = db.get(Participant, to_int(form.get("participant_id")))
        if not participant:
            add_flash(request, "Select a valid participant.", "error")
        else:
            request.session["participant_id"] = participant.id
            add_flash(request, f"You are voting as {participant.name}.")
    return redirect(request, "index")


@app.post("/rename", name="rename")
async def rename(request: Request):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        if participant:
            name = str(form.get("name", "")).strip()
            if len(name) < 2:
                add_flash(request, "Please enter a name.", "error")
            else:
                participant.name = name[:80]
                participant.email = str(form.get("email", "")).strip()[:160]
                db.commit()
                add_flash(request, "Participant profile updated.")
    return redirect(request, "index", "#profile")


@app.post("/preferences", name="save_preferences")
async def save_preferences(request: Request):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        if not participant:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        pref = db.scalar(select(Preference).where(Preference.participant_id == participant.id))
        if not pref:
            pref = Preference(participant_id=participant.id)
            db.add(pref)
        pref.budget_min = to_int(form.get("budget_min"))
        pref.budget_max = to_int(form.get("budget_max"))
        pref.preferred_month = str(form.get("preferred_month", ""))[:80]
        pref.pace = str(form.get("pace", "balanced"))[:30]
        pref.room_preference = str(form.get("room_preference", ""))[:80]
        pref.must_have = str(form.get("must_have", ""))[:180]
        pref.deal_breaker = str(form.get("deal_breaker", ""))[:180]
        pref.notes = str(form.get("notes", ""))[:1000]
        db.commit()
        add_flash(request, "Your travel preferences are saved.")
    return redirect(request, "index", "#preferences")


@app.post("/vote/destination/{destination_id}", name="vote_destination")
async def vote_destination(request: Request, destination_id: int):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        destination = db.get(Destination, destination_id)
        if not participant or not destination:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        vote = db.scalar(select(DestinationVote).where(
            DestinationVote.participant_id == participant.id,
            DestinationVote.destination_id == destination.id
        ))
        if not vote:
            vote = DestinationVote(participant_id=participant.id, destination_id=destination.id)
            db.add(vote)
        vote.score = max(1, min(5, to_int(form.get("score"), 3)))
        vote.rank = max(1, min(3, to_int(form.get("rank"), 2)))
        support = str(form.get("support", "maybe"))
        vote.support = support if support in {"yes", "maybe", "no"} else "maybe"
        vote.comment = str(form.get("comment", ""))[:260]
        db.commit()
        add_flash(request, f"Your vote for {destination.title} is saved.")
        return redirect(request, "index", f"#destination-{destination.slug}")


@app.post("/vote/activity/{activity_id}", name="vote_activity")
async def vote_activity(request: Request, activity_id: int):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        activity = db.get(Activity, activity_id)
        if not participant or not activity:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        value = str(form.get("vote", "maybe"))
        value = value if value in {"yes", "maybe", "no"} else "maybe"
        vote = db.scalar(select(ActivityVote).where(
            ActivityVote.participant_id == participant.id,
            ActivityVote.activity_id == activity.id
        ))
        if not vote:
            vote = ActivityVote(participant_id=participant.id, activity_id=activity.id)
            db.add(vote)
        vote.vote = value
        db.commit()
        return redirect(request, "index", f"#destination-{activity.destination.slug}")


@app.post("/dates", name="add_date")
async def add_date(request: Request):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        if not participant:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        try:
            start = datetime.strptime(str(form.get("start_date", "")), "%Y-%m-%d").date()
            end = datetime.strptime(str(form.get("end_date", "")), "%Y-%m-%d").date()
        except ValueError:
            add_flash(request, "Enter valid start and end dates.", "error")
            return redirect(request, "index", "#dates")
        if end <= start:
            add_flash(request, "The end date must be after the start date.", "error")
            return redirect(request, "index", "#dates")
        label = str(form.get("label", "")).strip() or f"{start:%d %b} – {end:%d %b}"
        db.add(DateOption(label=label[:120], start_date=start, end_date=end, created_by=participant.id))
        db.commit()
        add_flash(request, "Date option added.")
    return redirect(request, "index", "#dates")


@app.post("/vote/date/{date_option_id}", name="vote_date")
async def vote_date(request: Request, date_option_id: int):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        option = db.get(DateOption, date_option_id)
        if not participant or not option:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        value = str(form.get("vote", "maybe"))
        value = value if value in {"yes", "maybe", "no"} else "maybe"
        vote = db.scalar(select(DateVote).where(
            DateVote.participant_id == participant.id,
            DateVote.date_option_id == option.id
        ))
        if not vote:
            vote = DateVote(participant_id=participant.id, date_option_id=option.id)
            db.add(vote)
        vote.vote = value
        db.commit()
    return redirect(request, "index", "#dates")


@app.post("/comments", name="add_comment")
async def add_comment(request: Request):
    form = await request.form()
    with SessionLocal() as db:
        participant = current_participant(request, db)
        if not participant:
            add_flash(request, "Choose your participant slot first.", "error")
            return redirect(request, "index")
        body = str(form.get("body", "")).strip()
        destination_id = to_int(form.get("destination_id"))
        if len(body) < 2:
            add_flash(request, "Write a comment first.", "error")
        else:
            db.add(Comment(participant_id=participant.id, destination_id=destination_id, body=body[:1200]))
            db.commit()
            add_flash(request, "Comment added.")
    return redirect(request, "index", "#discussion")


@app.get("/organizer", response_class=HTMLResponse, name="organizer")
async def organizer(request: Request):
    with SessionLocal() as db:
        return render(request, "organizer.html", {
            **dashboard_data(db),
            "participant": current_participant(request, db),
            "organizer_access": request.session.get("organizer_access", False),
            "reservations": db.scalars(select(Reservation).order_by(Reservation.created_at.desc())).all()
        })


@app.post("/organizer", name="organizer_login")
async def organizer_login(request: Request):
    form = await request.form()
    if form.get("action") == "login":
        if form.get("code") == ADMIN_CODE:
            request.session["organizer_access"] = True
            add_flash(request, "Organizer mode unlocked.")
        else:
            add_flash(request, "Incorrect organizer code.", "error")
    return redirect(request, "organizer")


@app.post("/organizer/lock", name="lock_destination")
async def lock_destination(request: Request):
    form = await request.form()
    if not request.session.get("organizer_access"):
        add_flash(request, "Organizer access is required.", "error")
        return redirect(request, "organizer")
    with SessionLocal() as db:
        destination = db.get(Destination, to_int(form.get("destination_id")))
        if destination:
            set_setting(db, "locked_destination_id", destination.id)
            add_flash(request, f"{destination.title} is now the locked group choice.")
        else:
            add_flash(request, "Choose a destination.", "error")
    return redirect(request, "organizer")


@app.post("/organizer/unlock", name="unlock_destination")
async def unlock_destination(request: Request):
    if not request.session.get("organizer_access"):
        add_flash(request, "Organizer access is required.", "error")
        return redirect(request, "organizer")
    with SessionLocal() as db:
        set_setting(db, "locked_destination_id", "")
    add_flash(request, "The destination is unlocked.")
    return redirect(request, "organizer")


@app.post("/organizer/reservations", name="add_reservation")
async def add_reservation(request: Request):
    form = await request.form()
    if not request.session.get("organizer_access"):
        add_flash(request, "Organizer access is required.", "error")
        return redirect(request, "organizer")
    due_date = None
    if form.get("due_date"):
        try:
            due_date = datetime.strptime(str(form.get("due_date")), "%Y-%m-%d").date()
        except ValueError:
            pass
    amount = None
    if form.get("amount"):
        try:
            amount = Decimal(str(form.get("amount")))
        except InvalidOperation:
            pass
    with SessionLocal() as db:
        db.add(Reservation(
            category=str(form.get("category", "Other"))[:50],
            item=str(form.get("item", "Untitled"))[:180],
            provider=str(form.get("provider", ""))[:150],
            status=str(form.get("status", "researching"))[:30],
            due_date=due_date, amount=amount,
            currency=str(form.get("currency", "SAR"))[:10],
            confirmation=str(form.get("confirmation", ""))[:120],
            owner=str(form.get("owner", ""))[:100],
            notes=str(form.get("notes", ""))[:1000],
        ))
        db.commit()
    add_flash(request, "Reservation item added.")
    return redirect(request, "organizer", "#reservations")


@app.post("/organizer/reservations/{reservation_id}", name="update_reservation")
async def update_reservation(request: Request, reservation_id: int):
    form = await request.form()
    if not request.session.get("organizer_access"):
        add_flash(request, "Organizer access is required.", "error")
        return redirect(request, "organizer")
    with SessionLocal() as db:
        reservation = db.get(Reservation, reservation_id)
        if reservation:
            reservation.status = str(form.get("status", reservation.status))[:30]
            reservation.confirmation = str(form.get("confirmation", reservation.confirmation))[:120]
            reservation.notes = str(form.get("notes", reservation.notes))[:1000]
            db.commit()
            add_flash(request, "Reservation updated.")
    return redirect(request, "organizer", "#reservations")


@app.get("/api/summary", name="api_summary")
async def api_summary():
    with SessionLocal() as db:
        data = dashboard_data(db)
        return JSONResponse({
            "consensus_required": data["consensus_required"],
            "locked_destination": data["locked_destination"].title if data["locked_destination"] else None,
            "destinations": [{
                "title": stat["destination"].title, "yes": stat["yes"], "maybe": stat["maybe"],
                "no": stat["no"], "average_score": stat["avg_score"], "rank_one": stat["rank_one"],
                "responses": stat["responses"], "consensus": stat["consensus"]
            } for stat in data["destination_stats"]]
        })


@app.get("/leave", name="leave")
async def leave(request: Request):
    request.session.clear()
    return redirect(request, "index")
