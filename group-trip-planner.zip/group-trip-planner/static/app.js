
document.querySelectorAll(".flash").forEach((el) => {
  window.setTimeout(() => {
    el.style.opacity = "0";
    el.style.transform = "translateY(-8px)";
    window.setTimeout(() => el.remove(), 250);
  }, 3500);
});

document.querySelectorAll('input[type="date"]').forEach((input) => {
  if (!input.min) {
    const today = new Date();
    input.min = today.toISOString().split("T")[0];
  }
});
