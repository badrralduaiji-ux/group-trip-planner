# Nine-person Group Trip Planner

A responsive full-stack voting and coordination site for a one-week group trip.

## Included

- Nine editable participant slots
- Three tailored destination concepts
- Per-person budget, pace, room and activity preferences
- Destination scoring, ranking and yes/no support
- Activity voting for each itinerary
- Date proposals and date voting
- Group comments
- Consensus meter requiring 7 of 9 supporters
- Organizer-only destination lock
- Reservation tracker for flights, hotels, transfers, dining and activities
- SQLite locally; PostgreSQL automatically when `DATABASE_URL` is set

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env             # optional; export the variables manually
uvicorn app:app --reload
```

Open `http://127.0.0.1:5000`.

Default organizer code for local testing: `badr-trip`
Change it in production with the `ADMIN_CODE` environment variable.

## Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render, choose **New > Blueprint**.
3. Connect the repository; Render reads `render.yaml`.
4. Set `ADMIN_CODE` when prompted.
5. Open the public URL and replace the placeholder link in your Gmail draft.

## Important

The reservation tracker records decisions and booking details; it does not charge a card or book with airlines/hotels automatically. Real booking should remain organizer-approved after the group locks the destination.
